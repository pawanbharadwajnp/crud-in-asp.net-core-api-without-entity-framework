﻿using Microsoft.AspNetCore.Mvc;
using System.Collections.Generic;
using System.Net.Http.Headers;
using System.Net.Http;
using System.Security.Cryptography.Xml;
using System.Security.Policy;
using System;
using System.IO;
using System.Net;
using System.Text;
using WebApplication2.Model;
using Newtonsoft.Json;
using System.Threading.Tasks;
using System.Net.Http.Json;

namespace WebApplication2.Controllers
{
    public class HomeController : Controller
    {
        static HttpClient client = new HttpClient();

        [HttpGet("getdata")]
        public async Task<string> Get()
        {
            return  await GetProductAsync("https://localhost:44316/all/");



        }

        static async Task<string> GetProductAsync(string path)
        {
            string product = null;
            HttpResponseMessage response = await client.GetAsync(path);

              

            if (response != null)
            {
                if (response.IsSuccessStatusCode)
                {
                    product = await response.Content.ReadAsStringAsync();   
                }
                return product;
            }

            return null;
            
        }




    }
}

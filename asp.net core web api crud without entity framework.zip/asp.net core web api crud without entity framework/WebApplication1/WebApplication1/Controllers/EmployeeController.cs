﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.Data.SqlClient;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using WebApplication1.Context;
using WebApplication1.Model;

namespace WebApplication1.Controllers
{
    public class EmployeeController
    {
      

        [HttpGet("all")]
        public IEnumerable<Employee> Get()
        {
            IDbContext context = new DbContext();

            return context.connection();
            
        }


      
    }
}

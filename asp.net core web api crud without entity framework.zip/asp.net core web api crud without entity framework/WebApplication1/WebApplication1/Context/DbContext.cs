﻿
using Microsoft.Data.SqlClient;
using Microsoft.EntityFrameworkCore;
using Microsoft.IdentityModel.Protocols;
using NLog.Internal;
using System;
using System.Collections.Generic;
using System.Configuration;  // need this
using System.Data;
using WebApplication1.Model;

namespace WebApplication1.Context
{
    public class DbContext : IDbContext
    {
        public DbContext() { }
        public DbSet<Employee> employees { get; set; }

        public IEnumerable<Employee>  connection()
        {
            string connection_string = $"Server=(localdb)\\mssqllocaldb;Database=MyDatabase;Trusted_Connection=True;"; // instad of this

            //   string connection_string = ConfigurationManager.ConnectionStrings["ConnectionStrings"].ConnectionString;// returns connection string from app.config


            SqlConnection con = null;

            try
            {

                using (con = new SqlConnection(connection_string))
                {
                    con.Open();
                    if (con.State != ConnectionState.Open)
                    {
                        Console.WriteLine(" Connection Failed ");
                    }
                    else
                    {
                        // Write SQL statements here
                        //--------------| SELECTION |------------------------
                        string querry = " select * from Employee";

                        SqlCommand cmd = new SqlCommand(querry, con);

                        SqlDataReader result = cmd.ExecuteReader(); // executes querry and returns output


                        List<Employee> employeeslist = new List<Employee>();

                        while (result.Read() )
                        {
                            Employee employee = new Employee();
                           

                            employee.Id = (int)result["id"];
                              employee.Name= (string)result["name"];
                            employee.City = (string)result["city"];

                            employeeslist.Add( employee);


                        }

                        return employeeslist;
                        //return employeesList;

                    }
                }

            }
            catch (SqlException ex)
            {
                Console.WriteLine("Message : " + ex.Message + " \n Line Number : " + ex.LineNumber);
            }
            finally
            {
                con.Close();
            }

            return null;


        }

    }
}

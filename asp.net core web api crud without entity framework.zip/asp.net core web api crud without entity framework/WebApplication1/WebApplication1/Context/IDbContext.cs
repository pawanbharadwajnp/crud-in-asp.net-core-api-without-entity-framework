﻿using System.Collections.Generic;
using System.Diagnostics;
using WebApplication1.Model;

namespace WebApplication1.Context
{
    public interface IDbContext
    {
        public IEnumerable<Employee> connection();

    }
}
